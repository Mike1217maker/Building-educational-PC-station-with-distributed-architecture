create definer = `mysql.sys`@localhost view x$schema_flattened_keys as
select `information_schema`.`STATISTICS`.`TABLE_SCHEMA`                                 AS `table_schema`,
       `information_schema`.`STATISTICS`.`TABLE_NAME`                                   AS `table_name`,
       `information_schema`.`STATISTICS`.`INDEX_NAME`                                   AS `index_name`,
       max(`information_schema`.`STATISTICS`.`NON_UNIQUE`)                              AS `non_unique`,
       max(if(isnull(`information_schema`.`STATISTICS`.`SUB_PART`), 0, 1))              AS `subpart_exists`,
       group_concat(`information_schema`.`STATISTICS`.`COLUMN_NAME` order by
                    `information_schema`.`STATISTICS`.`SEQ_IN_INDEX` ASC separator ',') AS `index_columns`
from `INFORMATION_SCHEMA`.`STATISTICS`
where ((`information_schema`.`STATISTICS`.`INDEX_TYPE` = 'BTREE') and
       (`information_schema`.`STATISTICS`.`TABLE_SCHEMA` not in
        ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
group by `information_schema`.`STATISTICS`.`TABLE_SCHEMA`, `information_schema`.`STATISTICS`.`TABLE_NAME`,
         `information_schema`.`STATISTICS`.`INDEX_NAME`;

